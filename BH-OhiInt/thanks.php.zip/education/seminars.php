<!DOCTYPE html>
<html>
    
    <head>
    <title>In-House Training Seminars | OHI International</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="/favicon.ico">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="OHI incorporates a global family of brands, including The Orthotic Group (TOG), Langer Biomechanics, Arizona Foot Orthotics, Apex Footwear and Australian Orthotic Group as the global leader in technologies and treatment options for conditions associated with the lower extremities.
" />
	<link rel="stylesheet" type="text/css" href="/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="/slick/slick-theme.css">
	<link rel="stylesheet" href="/css/skel.css" />
    <link rel="stylesheet" href="/css/style.css" />
	
    <!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
	<script src="/js/jquery.min.js"></script>	
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-169258766-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-169258766-1');
    </script>

    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script>
        function enableSubmit() {
          var btn = document.getElementById('submit-form');
          btn.disabled = false;
          btn.title = '';
        }
    </script>
</head>


	<body id="top">

        <!-- Header -->
<header id="main-header">
	<div class="header-wrapper">
		<h1><a href="/" class="site-title" ><img src="/images/ohi-international-logo.png" /></a></h1>
		<label for="show-menu" class="mobile-menu"><i class="fa fa-bars" aria-hidden="true"></i></label>
		<input type="checkbox" id="show-menu" role="button">
		<nav>
			<ul>
				<li><a href="/index.html">Home</a></li>
				<li>
					<label for="product-menu"><a href="/products/orthotics/index.html">Products</a></label>
					<input type="checkbox" id="product-menu" role="button">
					<ul>
						<label for="product-menu" class="nav-return">&larr;</label>
						<li>
							<label for="technology-menu"><a href="/products/technology/index.html">Technology</a></label>
							<input type="checkbox" id="technology-menu" role="button">
							<ul>
								<label for="technology-menu" class="nav-return">&larr;</label>
								<li><a href="/products/technology/gaitscan/index.html">GaitScan</a></li>
								<li><a href="/products/technology/ohi1scan/index.html">OHI1Scan</a></li>
							</ul>
						</li>
						<li>
							<label for="orthotics-menu"><a href="/products/orthotics/inserts/index.html">Functional Orthoses</a></label>
							<input type="checkbox" id="orthotics-menu" role="button">
							<ul>
								<label for="orthotics-menu" class="nav-return">&larr;</label>
								<li><a href="/products/orthotics/inserts/index.html">Functional Orthoses</a></li>
								<li><a href="/products/orthotics/modifications/index.html">Modifications<br/> &amp; Additions</a></li>
								<li><a href="/products/orthotics/top-covers/index.html">Top Covers</a></li>
							</ul>
						</li>
						<li><a href="/products/prefabricated-orthotics/index.html">Prefabricated Orthotics</a></li>
					</ul>
				</li>
				<li>
					<label for="education-menu"><a href="/#education">Education</a></label>
					<input type="checkbox" id="education-menu" role="button">
					<ul>
						<label for="education-menu" class="nav-return">&larr;</label>
						<li><a href="/education/webinars.html">Webinars</a></li>
						<li><a href="/education/seminars.html">Seminars</a></li>
						<li><a href="//ohi.net/MarketingPortal/login.html">Practice Accelerator</a></li>
					</ul>
				</li>
				<li><a href="/downloads/index.html">Downloads</a></li>
				<li>
					<label for="about-menu"><a href="/#about">About</a></label>
					<input type="checkbox" id="about-menu" role="button">
					<ul>
						<label for="about-menu" class="nav-return">&larr;</label>
						<li><a href="/#about">About Us</a></li>
						<li><a href="/about/meet-our-staff.html">Meet Our Staff</a></li>
						<li><a href="/privacy-policy.html">Privacy Policy</a></li>
					</ul>
				</li>
				<li><a href="/contact.html">Contact</a></li>
			</ul>
		</nav>
        <a href="tel:02886747074" class="phone-link"><i class="fa fa-phone"></i>&nbsp;&nbsp;028 867 47074</a>
	</div>
</header>


        <section id="banner">
		<img class="full" src="../images/education/seminar-header.jpg" />
</section>

<section class="wrapper collapse-padding-down">
	<div class="container">
		<header class="major collapse-down">
			<h2>In-House Training<span>Seminars</span></h2>
		</header>
		<div class="row">
			<div class="12u">
				<p>Once that the pandemic is over and restrictions in the UK lifted, OHI International will be running in-house training seminars again. During these seminars you are invited to attend OHI International head office in Cookstown, Northern Ireland for training in biomechanics, theory and practical as well as GaitScan interpretation and Orthotic prescription. Additionally, you will have an opportunity to meet the team and learn the processes, see all the materials we use and get answers to all your questions.</p>
                <p>Training will be given in 2 days followed by dinner and a few drinks, part of the Northern Irish hospitality.</p>
			</div>
		</div>
	</div>
</section>

<section class="wrapper">
	<div class="container">
		<div class="row">
			<header class="major">
				<h2><span>Interested in Attending?</span></h2>
			</header>
			<div class="12u">
				<p>If you’d like to know more about the training seminars or would like to register, click the button below and let us know.</p>
			</div>
		</div>
		<div class="row">
			<div class="12u">
				<form id="contact-form" action="https://liveformhq.com/form/c88c5594-ec76-4260-8655-09ac1b61b65b" method="POST" accept-charset="utf-8">
                    <input type="hidden" value="http://www.ohiinternational.com/thanks.html" name="_redirect" />
                    <input type="hidden" value="Seminar Information Request" name="subject" />
                    <input type="hidden" value="Seminar Information Request" name="type" />
					<div class="row">
						<div class="indicates-required"><span class="asterisk">*</span> indicates required</div>
					</div>
					<div class="row">
						<div class="6u">
							<label for="name">Name <span class="asterisk">*</span></label>
							<input type="text" name="name" required />
						</div>
						<div class="6u">
							<label for="replyto">Email <span class="asterisk">*</span></label>
				            <input type="email" name="replyto" pattern="(?!(^[.-].*|[^@]*[.-]@|.*\.{2,}.*)|^.{254}.)([a-zA-Z0-9!#$%&'*+\/=?^_`{|}~.-]+@)(?!-.*|.*-\.)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,15}" class="small" required />
						</div>
					</div>
					<div class="row">
						<div class="6u">
							<label for="phone">Phone <span class="asterisk">*</span></label>
							<input type="tel" name="phone" required />
						</div>
						<div class="6u">
							<label for="practiceName">Practice Name <span class="asterisk">*</span></label>
							<input type="text" name="practiceName" required />
						</div>
						<div class="12u">
							<label for="message">Message</label>
							<textarea name="message"></textarea>
						</div>
					</div>
					<div class="g-recaptcha" data-sitekey="6LeLp5QUAAAAAHG0zhVWLRdVayWAaRjeq3iVCG6c"></div>
                    <div id="recaptcha-error" class="error">ERROR: Please check the reCAPTCHA box and click Submit again</div>
                    <button id="submit-form" type="submit" class="button space-up">Contact Us</button>
				</form>
			</div>
		</div>
	</div>
</section>


        <!-- Footer -->
<footer id="footer">
    <div class="container">
        <div class="row">
            <h4>Locations</h4>
        </div>
        <div class="row collapse-at-2">
            <div class="3u footer-col">
                <h5>Western Europe</h5>
                <p>133 Moneymore Rd.<br/>
                Cookstown, Co. Tyrone<br/>
                BT80 9UU<br/>
                028 867 47074</p>
            </div>
            <div class="3u footer-col">
                <h5>Global Headquarters</h5>
                <p>Orthotic Holdings, Inc.<br/>
                Mesa, AZ</p>
            </div>
        </div>
        <ul class="copyright">
            <li>&copy; OHI International. All rights reserved.</li>
        </ul>
    </div>
</footer>

<script>
    $("#contact-form").submit(function(event) {
       var recaptcha = $("#g-recaptcha-response").val();
       if (recaptcha === "") {
          event.preventDefault();
          $("#recaptcha-error").css('display', 'block');
       }
    });
</script>
        
    </body>

</html>
