$(document).ready(function(){
	$('.gaitscan-features-slider').slick({
		arrows: true,
		centerPadding: '0px',
		slidesToShow: 1
	});
});
